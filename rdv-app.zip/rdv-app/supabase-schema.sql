-- À copier-coller dans l'éditeur SQL de Supabase (Table Editor > SQL Editor > New query)

create extension if not exists "pgcrypto";

create table demandes (
  id uuid primary key default gen_random_uuid(),
  creator_name text not null,
  creator_email text not null,
  type text not null check (type in ('galant', 'potes', 'repas', 'autre')),
  date date not null,
  heure time not null,
  nb_personnes int not null check (nb_personnes >= 1),
  resto_options jsonb not null default '[]',
  activite_options jsonb not null default '[]',
  status text not null default 'active' check (status in ('active', 'expired')),
  created_at timestamptz not null default now(),
  expired_at timestamptz
);

create table reponses (
  id uuid primary key default gen_random_uuid(),
  demande_id uuid not null references demandes(id) on delete cascade,
  resto_choice text,
  activite_choice text,
  responded_at timestamptz not null default now()
);

-- Sécurité : on autorise la lecture/écriture publique via la clé "anon"
-- car le site n'a pas de comptes utilisateurs. La protection vient du fait
-- que l'id de la demande (uuid) sert de "mot de passe" dans le lien.
alter table demandes enable row level security;
alter table reponses enable row level security;

create policy "Lecture publique des demandes" on demandes
  for select using (true);

create policy "Création publique des demandes" on demandes
  for insert with check (true);

create policy "Mise à jour publique du statut" on demandes
  for update using (true);

create policy "Lecture publique des reponses" on reponses
  for select using (true);

create policy "Création publique des reponses" on reponses
  for insert with check (true);
